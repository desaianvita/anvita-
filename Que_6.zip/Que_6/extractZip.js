const extract = require('extract-zip');
const path = require('path');

const extractZipFile = async (zipFilePath, outputFolder) => {
    try {
        await extract(zipFilePath, { dir: outputFolder });
        console.log('Extraction complete.');
    } catch (err) {
        console.error('Error during extraction:', err);
    }
};

const zipFilePath = process.argv[2];
const outputFolder = process.argv[3] || path.join(__dirname, 'extracted');

if (!zipFilePath) {
    console.error('Please provide the path to a zip file.');
    process.exit(1);
}

extractZipFile(zipFilePath, outputFolder);
