const express = require("express");
const { WebSocketServer } = require("ws");
const getResponse = require("./chatbot");

// Initialize Express app
const app = express();
const PORT = 3000;

// Serve static files from the "public" directory
app.use(express.static("public"));

// Start HTTP server on port 3000
const server = app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

// Create WebSocket server and bind it to the same HTTP server
const wss = new WebSocketServer({ server });

wss.on("connection", (ws) => {
  console.log("New client connected!");

  // Listen for messages from the client
  ws.on("message", (message) => {
    console.log("Received from client:", message);

    // Generate chatbot response and send it back to the client
    const response = getResponse(message.toString());
    ws.send(response);
  });

  ws.on("close", () => {
    console.log("Client disconnected.");
  });
});
