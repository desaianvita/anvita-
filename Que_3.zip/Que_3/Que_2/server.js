const readlineSync = require("readline-sync");
const getResponse = require("./chatbot");

console.log("Welcome to the Customer Support Chatbot! Type 'exit' to quit.");

while (true) {
  const userInput = readlineSync.question("You: ");
  
  if (userInput.toLowerCase() === "exit") {
    console.log("Chatbot: Goodbye! Have a great day!");
    break;
  }

  const botResponse = getResponse(userInput);
  console.log("Chatbot:", botResponse);
}
